package runnerBDD;

import org.testng.annotations.DataProvider;

import base.ProjectSpecificMethods;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/test/java/features/CreateLead.feature"},glue = {"pages"},
publish = true,monochrome = true,dryRun = false )
public class CreateLeadBDD  extends ProjectSpecificMethods{
	@DataProvider(parallel = true)
    public Object[][] scenarios() {
        
        return super.scenarios();
    }

}
