package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataLibrary {
	
	public static String[][] readValesFromExcel(String fileName) throws IOException {
		XSSFWorkbook workBook = new XSSFWorkbook("./data/"+fileName+".xlsx");
		XSSFSheet sheet = workBook.getSheetAt(0);
		XSSFRow rowNo1 = sheet.getRow(1);
		int totalRowCount = sheet.getLastRowNum();
		short totalColumnCount = rowNo1.getLastCellNum();
		String[][] data = new String[totalRowCount][totalColumnCount];
		for (int i = 1; i <= totalRowCount; i++) { 
			XSSFRow row = sheet.getRow(i);
			System.out.print(" | ");
			for (int j = 0; j < totalColumnCount; j++) {
				String stringCellValue = row.getCell(j).getStringCellValue();
				System.out.print(stringCellValue + " | ");
				data[i-1][j]=stringCellValue;
			}
			System.out.println();	
	}
	workBook.close();
	return data;
	}
	}
