package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataLibrary;

public class ProjectSpecificMethods  extends AbstractTestNGCucumberTests{
	//public static ChromeDriver driver; //declared the driver , value is null here
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<>();
	public String fileName;
	@BeforeMethod
	public void preConditions() {
		ChromeOptions options =  new ChromeOptions();
		options.addArguments("guest");
		//driver  = new ChromeDriver(options);
		setRd(new FirefoxDriver());
		System.out.println(getRd());
		getRd().manage().window().maximize();
		getRd().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		getRd().get("http://leaftaps.com/opentaps/control/main");
	}
	@AfterMethod
	public void postConditions() {
		getRd().close();
	}
	//getter method
	public  RemoteWebDriver getRd() {
		return rd.get();
	}
	//setter method
	public void setRd(RemoteWebDriver driver) {
		rd.set(driver);
	}
	@DataProvider(name="fetchExcelData")
	public String[][] sendData() throws IOException {
		return DataLibrary.readValesFromExcel(fileName);
	}
}
