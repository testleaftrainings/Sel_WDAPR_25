package week7.day1;

public class LearnThrows {

	public static void main(String[] args) throws Exception   {
		Thread.sleep(3000);
	}

}
