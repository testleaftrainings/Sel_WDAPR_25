package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {

//	public LoginPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	@When("The user enters the username as {string}")
	public LoginPage enterUserName(String uname) throws IOException {
		System.out.println(getRd());
		getRd().findElement(By.id("username")).sendKeys(uname);
		reportStep("Pass", "Username entered successfully");
		return this;
	}
	@When("The user enters the password as {string}")
	public LoginPage enterPassword(String pword) throws IOException {
		getRd().findElement(By.id("password")).sendKeys(pword);
		reportStep("Pass", "Password entered succesfully");
		return this;
	}
	@When("The user clicks the login button")
	public WelcomePage clickLoginButton() {
		getRd().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}
	
	
}
