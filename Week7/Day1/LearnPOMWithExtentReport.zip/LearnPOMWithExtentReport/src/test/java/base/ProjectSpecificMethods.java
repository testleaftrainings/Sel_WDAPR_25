package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataLibrary;

public class ProjectSpecificMethods  extends AbstractTestNGCucumberTests{
	//public static ChromeDriver driver; //declared the driver , value is null here
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<>();
	public static String fileName;
	public static ExtentReports extent;
	public static String testName, testDescription,testAuthor,testCategory;
	public static ExtentTest test;
	
	@BeforeSuite
	public void startReport() {
		//Step 1: Set Physical Report Path	
		ExtentHtmlReporter html = new ExtentHtmlReporter("./reports/result.html");
				//Step 2: Create ExtentReports Object
				extent = new ExtentReports();
				//Step 3: Attach Reporter to ExtentReports
				extent.attachReporter(html);

	}
	@BeforeClass
	public void tescaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	public void reportStep(String status,String message) throws IOException {
		if (status.equals("Pass")) {
			test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath("./snaps/image"+takeSnap()+".png").build());
		}
		else {
			test.fail(message,MediaEntityBuilder.createScreenCaptureFromPath("./snaps/image"+takeSnap()+".png").build());
		}

	}
	
	public int takeSnap() throws IOException {
		int randomNumber=(int)(Math.random()*9999999+999999);
		File source = getRd().getScreenshotAs(OutputType.FILE);
		File destination=new File("./snaps/image"+randomNumber+".png");
		FileUtils.copyFile(source, destination);
        return randomNumber;
	}
	
	//image1234    12345      34567
	//image4567
	
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	
	
	@BeforeMethod
	public void preConditions() {
		ChromeOptions options =  new ChromeOptions();
		options.addArguments("guest");
		//driver  = new ChromeDriver(options);
		setRd(new FirefoxDriver());
		System.out.println(getRd());
		getRd().manage().window().maximize();
		getRd().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		getRd().get("http://leaftaps.com/opentaps/control/main");
	}
	@AfterMethod
	public void postConditions() {
		getRd().close();
	}
	//getter method
	public  RemoteWebDriver getRd() {
		return rd.get();
	}
	//setter method
	public void setRd(RemoteWebDriver driver) {
		rd.set(driver);
	}
	@DataProvider(name="fetchExcelData")
	public String[][] sendData() throws IOException {
		return DataLibrary.readValesFromExcel(fileName);
	}
}
