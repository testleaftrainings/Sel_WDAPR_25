package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC002CreateLead extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setPath() {
		fileName="LoginCredentials";
		testName="CreateLead";
		testDescription="CreateLead with multiple data";
		testAuthor="Bhuvanesh";
		testCategory="Regression";
	}
	
	@Test(dataProvider = "fetchExcelData")
	public void runCreateLead(String uname, String pword) throws IOException {
		LoginPage user = new LoginPage();
		//Fluent Interface --> which is like the sentence
		user.enterUserName(uname).enterPassword(pword)
		.clickLoginButton()
		.clickCRMSFALink()
		.clickLeadsTab()
		.clickCreateLeadMenu();
	}
}
