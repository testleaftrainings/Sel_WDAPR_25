package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC001LoginTest extends ProjectSpecificMethods {
	@BeforeTest
	public void setPath() {
		fileName="LoginCredentials";
		testName="Login";
		testDescription="Login with Valid credentials";
		testAuthor="Vineeth";
		testCategory="Regression";
	}
	
	@Test(dataProvider = "fetchExcelData")
	public void runLoginTest(String uname, String pword) throws IOException {
		LoginPage user = new LoginPage();
		//Fluent Interface --> which is like the sentence
		user.enterUserName(uname).enterPassword(pword).clickLoginButton().clickCRMSFALink();
}}
