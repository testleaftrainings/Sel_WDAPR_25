package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.When;

public class LoginPageSF extends ProjectSpecificMethods {
	@When("The user enters the username as {string}")
	public LoginPageSF enterUserName(String uname) {
		WebElement eleUsername = locateElement("username");
		clearAndType(eleUsername,uname);
		reportStep(uname+" Username entered successfully", "pass");
		return this;
	}
	@When("The user enters the password as {string}")
	public LoginPageSF enterPassword(String pword) {
		clearAndType(locateElement("password"), pword);
		reportStep(pword+" Password entered successfully", "pass");
		return this;

	}
	@When("The user clicks the login button")
	public LoginPageSF clickLogInButton() {
		click(locateElement("Login"));
		reportStep("Log In button is clicked successfully", "pass");
		return this;

	}

}
