package com.salesforce.bddrunner;

import org.testng.annotations.BeforeTest;

import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/main/java/features/LoginSalesforce.feature"},glue = {"com.salesforce.pages"},dryRun = false)
public class TC001LoginTest extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setValues() {
		testcaseName = "VerifyLogin for Saleforce";
		testDescription ="The user attempt to login with the valid Credentials";
		authors="Bhuvanesh";
		category ="Sanity";
	
	}

}
